University Course Hub

Project Overview

The University Course Hub is a web application designed for a UK university to market its undergraduate and postgraduate degree programmes to prospective students. This system allows students to explore courses, view detailed programme descriptions, register their interest, and receive updates. It also includes an admin panel for managing programme data and student registrations.

Features

Student-Facing Interface

View a list of undergraduate and postgraduate programmes.

See detailed descriptions of each programme.

Browse modules for each programme.

View programme leaders and module leaders.

Filter programmes by level (Undergraduate/Postgraduate).

Search for programmes using keywords.

Register interest in a programme and receive updates.

Mobile-friendly design with WCAG2 accessibility compliance.

Student Portal

Visit the homepage to browse available Undergraduate and Postgraduate courses.

Use the search feature to find specific programmes.

Click on a programme to see its modules and staff information.

Fill out the registration form to express interest in a programme.