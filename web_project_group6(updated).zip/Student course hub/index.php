<?php
include 'config.php'; // Database connection
include 'login.php';

// Handle search and filter
$search_term = '';
$level_filter = '';
$params = [];
$query = "SELECT * FROM programs";

// If search term is provided
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = "%" . $_GET['search'] . "%";
    $query .= " WHERE title LIKE ? OR description LIKE ?";
    $params[] = $search_term;
    $params[] = $search_term;
} elseif (isset($_GET['level']) && in_array($_GET['level'], ['Undergraduate', 'Postgraduate'])) {
    $query .= " WHERE level = ?";
    $params[] = $_GET['level'];
}

$stmt = $conn->prepare($query);

if (!empty($params)) {
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Course Hub</title>
    <link rel="stylesheet" href="style.css">


</head>
<body>

    <header>
        <h1>University Course Hub</h1>
        <nav>
            <a href="index.php?level=Undergraduate">Undergraduate</a>
            <a href="index.php?level=Postgraduate">Postgraduate</a>
            <a href="index.php">All Programmes</a>
        </nav>
    </header>

    <div class="container">
        <h2>Available Programmes</h2>

        <!-- Search Form -->
        <form action="index.php" method="GET" class="search-form">
            <input type="text" name="search" placeholder="Search Programmes..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button type="submit">Search</button>
        </form>

        <div class="program-list">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="program-card">
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo substr(htmlspecialchars($row['description']), 0, 100) . '...'; ?></p>
                    <a href="programme.php?id=<?php echo $row['id']; ?>" class="btn">View Details</a>
                </div>
            <?php } ?>
        </div>
    </div>

</body>
</html>



