<?php
include 'config.php'; // Database connection

// Check if the programme ID is provided
$programme_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($programme_id <= 0) {
    die("Invalid programme ID.");
}

// Fetch programme details
$sql = "SELECT * FROM programs WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $programme_id);
$stmt->execute();
$programme_result = $stmt->get_result();

if ($programme_result->num_rows === 0) {
    die("Programme not found.");
}

$programme = $programme_result->fetch_assoc();

// Fetch modules for this programme
$sql = "SELECT * FROM modules WHERE program_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $programme_id);
$stmt->execute();
$module_result = $stmt->get_result();

// Handle Form Submission
$successMessage = "";
$errorMessage = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    
    // Validate inputs
    if (!empty($name) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Insert into student_interests
        $insertSql = "INSERT INTO student_interests (name, email, program_id) VALUES (?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("ssi", $name, $email, $programme_id);
        
        if ($insertStmt->execute()) {
            $successMessage = "Thank you! Your interest has been registered.";
        } else {
            $errorMessage = "Error: Could not register your interest.";
        }
        
        $insertStmt->close();
    } else {
        $errorMessage = "Please enter a valid name and email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($programme['title']); ?> - Details</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

    <header>
        <h1>University Course Hub</h1>
    </header>

    <div class="container">
        <h2><?php echo htmlspecialchars($programme['title']); ?></h2>
        <p><strong>Level:</strong> <?php echo htmlspecialchars($programme['level']); ?></p>
        <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($programme['description'])); ?></p>

        <h3>Modules:</h3>
        <?php if ($module_result->num_rows > 0) { ?>
            <ul>
                <?php while ($module = $module_result->fetch_assoc()) { ?>
                    <li>
                        <strong><?php echo htmlspecialchars($module['title']); ?></strong> - <?php echo htmlspecialchars($module['description']); ?>
                    </li>
                <?php } ?>
            </ul>
        <?php } else { ?>
            <p>No modules available for this programme.</p>
        <?php } ?>

        <!-- Registration Form -->
        <h3>Register Your Interest</h3>
        
        <?php if ($successMessage): ?>
            <div class="alert success"> <?php echo $successMessage; ?> </div>
        <?php elseif ($errorMessage): ?>
            <div class="alert error"> <?php echo $errorMessage; ?> </div>
        <?php endif; ?>

        <form action="programme.php?id=<?php echo $programme_id; ?>" method="POST" class="form-container">
            <label for="name">Your Name:</label>
            <input type="text" name="name" id="name" placeholder="Your Name" required>
            
            <label for="email">Your Email:</label>
            <input type="email" name="email" id="email" placeholder="Your Email" required>
            
            <button type="submit">Register Interest</button>
        </form>
    </div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


