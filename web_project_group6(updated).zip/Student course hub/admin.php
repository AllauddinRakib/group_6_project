<?php
session_start();
include 'config.php';

// Check if the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "student_course_hub");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Create Program
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_program'])) {
    $title = $_POST['title'];
    $level = $_POST['level'];

    // Insert new program into database
    $stmt = $conn->prepare("INSERT INTO programs (title, level) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $level);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
}

// Handle Edit Program
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_program'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $level = $_POST['level'];

    // Update the program in the database
    $stmt = $conn->prepare("UPDATE programs SET title = ?, level = ? WHERE id = ?");
    $stmt->bind_param("ssi", $title, $level, $id);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
}

// Handle Delete Program
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];

    // Delete program from database
    $stmt = $conn->prepare("DELETE FROM programs WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit();
    } else {
        die("Error deleting the program.");
    }
}

// Fetch programs
$programs = $conn->query("SELECT * FROM programs");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Manage Programs</h2>
            <button class="btn btn-success" data-toggle="modal" data-target="#addProgramModal">+ Add New Program</button>
        </div>

        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Level</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $programs->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['level']) ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editProgramModal<?= $row['id'] ?>">Edit</button>
                            <a href="admin.php?delete_id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this program?')">Delete</a>
                        </td>
                    </tr>

                    <!-- Edit Program Modal -->
                    <div class="modal fade" id="editProgramModal<?= $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editProgramModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editProgramModalLabel">Edit Program</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <div class="form-group">
                                            <label for="title">Program Title</label>
                                            <input type="text" class="form-control" name="title" value="<?= htmlspecialchars($row['title']) ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="level">Level</label>
                                            <input type="text" class="form-control" name="level" value="<?= htmlspecialchars($row['level']) ?>" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" name="edit_program" class="btn btn-warning">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Program Modal -->
    <div class="modal fade" id="addProgramModal" tabindex="-1" role="dialog" aria-labelledby="addProgramModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addProgramModalLabel">Add New Program</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="title">Program Title</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="level">Level</label>
                            <input type="text" class="form-control" name="level" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="add_program" class="btn btn-success">Add Program</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


</body>
</html>

